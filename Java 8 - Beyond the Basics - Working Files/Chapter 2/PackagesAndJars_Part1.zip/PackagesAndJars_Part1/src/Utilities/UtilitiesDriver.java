package Utilities;

public class UtilitiesDriver {

	public static void main(String[] args) {
		System.out.println("X equals Y? " + Utilities.nullSafeEquals("X", "Y"));
	}

}
