package raceManagerSearching;
import raceManagerObjects.Athlete;

public interface AthleteFinder 
{
	public boolean searchForAthlete(Athlete searcher);
}
