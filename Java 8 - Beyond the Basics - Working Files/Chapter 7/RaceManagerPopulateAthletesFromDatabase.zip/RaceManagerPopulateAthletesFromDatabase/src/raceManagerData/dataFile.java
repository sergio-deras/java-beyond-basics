package raceManagerData;

public class dataFile 
{
	public static String dataFilePath = "C:\\JavaProjects\\InfiniteSkillsRaceManagerSaveAndRestoreState"
			+ "\\src\\raceManagerData\\raceManagerData.txt";

	public static String dataObjectFilePath = "C:\\JavaProjects\\InfiniteSkillsRaceManagerSaveAndRestoreState"
			+ "\\src\\raceManagerData\\raceManagerData.bin";
}
