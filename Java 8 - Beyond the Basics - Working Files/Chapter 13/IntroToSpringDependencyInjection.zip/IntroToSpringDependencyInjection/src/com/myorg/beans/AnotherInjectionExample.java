package com.myorg.beans;

public class AnotherInjectionExample 
{
 	private String message = null;

    public String getMessage() {
        return message;
    }

    public void setMessage(String msg) {
        message = msg;
    }
}
