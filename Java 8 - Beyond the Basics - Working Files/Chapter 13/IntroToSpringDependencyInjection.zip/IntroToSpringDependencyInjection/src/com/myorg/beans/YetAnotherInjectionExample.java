package com.myorg.beans;

public class YetAnotherInjectionExample {
	private String message = null;

    public String getMessage() {
        return message;
    }

    public void setMessage(String msg) {
        message = msg;
    }
}
