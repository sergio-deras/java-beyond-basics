package com.myorg.helpers;

import java.util.ArrayList;
import com.myorg.beans.Car;

public interface AutoSearcher {
	ArrayList<Car> getAutos();
}
