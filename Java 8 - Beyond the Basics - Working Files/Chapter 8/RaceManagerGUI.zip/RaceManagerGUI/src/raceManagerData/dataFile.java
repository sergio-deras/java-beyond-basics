package raceManagerData;

public class dataFile 
{
	public static String dataFilePath = "C:\\JavaProjects\\RaceManagerGUI"
			+ "\\src\\raceManagerData\\raceManagerData.txt";

	public static String dataObjectFilePath = "C:\\JavaProjects\\RaceManagerGUI"
			+ "\\src\\raceManagerData\\raceManagerData.bin";
}
