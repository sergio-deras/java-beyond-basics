package raceManagerData;

public class dataFile 
{
	public static String dataFilePath = "C:\\JavaProjects\\InfiniteSkillsRaceManagerPopulateFromTextFile"
			+ "\\src\\raceManagerData\\raceManagerData.txt";
}
