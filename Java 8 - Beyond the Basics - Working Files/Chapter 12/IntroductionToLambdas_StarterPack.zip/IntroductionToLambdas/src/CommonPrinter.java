
public class CommonPrinter 
{
	//create static runnable here:
	
	//define an interface for the FormatString signature
	
	//create an expression of the interface type
	
	//define an interface for the Console PrintObject
	
	//create the printobject for any object using type inference
}
