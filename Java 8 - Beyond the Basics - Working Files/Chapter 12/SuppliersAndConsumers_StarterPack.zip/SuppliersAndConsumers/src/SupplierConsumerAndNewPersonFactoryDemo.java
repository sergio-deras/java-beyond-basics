
public class SupplierConsumerAndNewPersonFactoryDemo 
{
	public static void main(String[] args)
	{
		
	}
}
