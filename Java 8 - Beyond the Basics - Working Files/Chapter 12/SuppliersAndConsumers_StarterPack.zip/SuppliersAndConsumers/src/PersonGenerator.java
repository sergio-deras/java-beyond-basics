import CustomObjects.Person;


public interface PersonGenerator<T extends Person> {

}
