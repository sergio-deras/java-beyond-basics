
public interface DataServer 
{
	void setCount(int sleepTime, String ID);
}
